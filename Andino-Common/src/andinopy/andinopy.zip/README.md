# Andio.Systems Python Library

## 1. Andino IO


## 2. Andino X1


## 3. Andino Terminal

### 3.1 IO - relays and optocoupler
For the usage of optocoupler please refer to the Andino IO parts.
