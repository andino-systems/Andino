## Nextion Display Resetten
Wenn ein Serieller Upload auf das Display unterbrochen wird, ist das DEvice in einem Bootloop gefangen.
### 1. SD vorbereiten
Formatieren Sie eine SD Karte mit mindestens 1MB speicher auf Fat32. Auf diese Karte kopieren sie lediglich die reset.tft
### 2. Reparatur
Trennen Sie das Display vom Strom und schieben Sie die SD Karte in den dafür vorgesehenen Slot ein.
Geben Sie wider Strom und warten, bis der Upload komplett ist. Entfernen Sie die Karte der Nextion kann nun wieder über Serial geflasht werden.