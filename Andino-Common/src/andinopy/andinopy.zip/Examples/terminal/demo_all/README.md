# Simple Demo of all the parts included in the Terminal
## 1. Preparation
Make sure to flash the image to the nextion device and make sure you configured your pi for the Terminal

## 2. Running
The display Should now display the counters for all inputs, the state of every relays and the last inputs from the Keyboard and RFID